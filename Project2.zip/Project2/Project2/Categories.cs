﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Project2
{
    public partial class Categories : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Cat;

        public Categories()
        {
            InitializeComponent();
        }

        DataTable GenerateTable()
        {
            dt = new DataTable("Categories");

            dc = new DataColumn("Catid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("CatName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("CatDescription", typeof(string));
            dt.Columns.Add(dc);

            return dt;

        }

        private void clear()
        {
            txtcid.Text = "";
            txtcname.Text = "";
            txtdesc.Text = "";
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string cid, cname, cdesc;
            cid = txtcid.Text;
            cname = txtcname.Text;
            cdesc = txtdesc.Text;
            try
            {
                dr = Cat.NewRow();
                dr[0] = int.Parse(cid);
                dr[1] = cname;
                dr[2] = cdesc;
                Cat.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }

        private void Categories_Load(object sender, EventArgs e)
        {
            Cat = GenerateTable();
            dataGridView1.DataSource = Cat;
        }

        private void txtcid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcid.Text, "[^0-9.]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtcid.Text = "";
            }
        }
    }
}
