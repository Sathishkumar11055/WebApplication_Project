﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class DashBoard : Form
    {
        public DashBoard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Categories c = new Categories();
            //c.Show();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Categories c = new Categories();
            c.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Customer cs = new Customer();
            cs.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Orders o = new Orders();
            o.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Offers of = new Offers();
            of.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CustomerInfo info = new CustomerInfo();
            info.Show();
        }
    }
}
