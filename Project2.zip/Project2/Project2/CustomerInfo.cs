﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Project2
{
    public partial class CustomerInfo : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable CustInfo;

        public CustomerInfo()
        {
            InitializeComponent();
        }

        DataTable GenerateTable()
        {
            dt = new DataTable("Customer_Info");

            dc = new DataColumn("Custid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("DateofBirth", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Payment", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Cashback_Offer", typeof(string));
            dt.Columns.Add(dc);

            return dt;

        }

        private void clear()
        {
            txtcid.Text = "";
            txtdateofbirth.Text = "" ;
            txtpayment.Text = "";
            txtcashback.Text = "";
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string cid, dateofbirth, payment, cashback;
            cid = txtcid.Text;
            dateofbirth = txtdateofbirth.Text;
            payment = txtpayment.Text;
            cashback = txtcashback.Text;
            try
            {
                dr = CustInfo.NewRow();
                dr[0] = int.Parse(cid);
                dr[1] = dateofbirth;
                dr[2] = payment;
                dr[3] = cashback;
                CustInfo.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }

        private void txtcid_TextChanged(object sender, EventArgs e)
        {

        }

        private void CustomerInfo_Load(object sender, EventArgs e)
        {
            CustInfo = GenerateTable();
            dataGridView1.DataSource = CustInfo;
        }
    }
}
