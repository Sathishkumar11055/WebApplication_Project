﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Project2
{
    public partial class Customer : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable cust;
        public Customer()
        {
            InitializeComponent();
        }

        private void txtdesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        DataTable GenerateTable()
        {
            dt = new DataTable("Customer");

            dc = new DataColumn("Custid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("CustName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("CustContact", typeof(double));
            dt.Columns.Add(dc);
            dc = new DataColumn("CustEmail", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("CustAddress", typeof(string));
            dt.Columns.Add(dc);

            return dt;
        }

        private void clear()
        {
            txtcid.Text = "";
            txtcname.Text = "";
            txtcontact.Text = "";
            txtemail.Text = "";
            txtaddress.Text = "";
        }

        private void txtcid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtcid.Text = "";
            }
        }

        private void txtcontact_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcontact.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtcontact.Text = "";
            }
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string cid, cname, contact, email, address;
            cid = txtcid.Text;
            cname = txtcname.Text;
            contact = txtcontact.Text;
            email = txtemail.Text;
            address = txtaddress.Text;
            try
            {
                dr = cust.NewRow();
                dr[0] = int.Parse(cid);
                dr[1] = cname;
                dr[2] = double.Parse(contact);
                dr[3] = email;
                dr[4] = address;
                cust.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            cust = GenerateTable();
            dataGridView1.DataSource = cust;
        }
    }
}
