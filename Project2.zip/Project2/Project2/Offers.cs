﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Project2
{
    public partial class Offers : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Off;
        public Offers()
        {
            InitializeComponent();
        }

        DataTable GenerateTable()
        {
            dt = new DataTable("Offers");

            dc = new DataColumn("Offerid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Discount", typeof(float));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Promo_Source", typeof(string));
            dt.Columns.Add(dc);

            return dt;

        }

        private void clear()
        {
            txtoid.Text = "";
            txtdis.Text = "";
            txtpromosource.Text = "";
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string oid, discount, promosource;
            oid = txtoid.Text;
            discount = txtdis.Text;
            promosource = txtpromosource.Text;
            try
            {
                dr = Off.NewRow();
                dr[0] = int.Parse(oid);
                dr[1] = float.Parse(discount);
                dr[2] = promosource;
                dt.Rows.Add(dr);
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }

        private void Offers_Load(object sender, EventArgs e)
        {
            Off = GenerateTable();
            dataGridView1.DataSource = Off;
        }

        private void txtoid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtoid.Text = "";
            }
        }

        private void txtdis_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtoid.Text = "";
            }
        }
    }
}
