﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Project2
{
    public partial class Orders : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Ord;
        public Orders()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        DataTable GenerateTable()
        {
            dt = new DataTable("Orders");

            dc = new DataColumn("Ordid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Prodid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };

            dc = new DataColumn("Quantity", typeof(int));
            dt.Columns.Add(dc);

            return dt;

        }

        private void clear()
        {
            txtoid.Text = "";
            txtpid.Text = "";
            txtquantity.Text = "";
        }
        private void Orders_Load(object sender, EventArgs e)
        {
            Ord = GenerateTable();
            dataGridView1.DataSource = Ord;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string oid, pid, quantity;
            oid = txtoid.Text;
            pid = txtpid.Text;
            quantity = txtquantity.Text;
            try
            {
                dr = Ord.NewRow();
                dr[0] = int.Parse(oid);
                dr[1] = int.Parse(pid);
                dr[2] = int.Parse(quantity);
                Ord.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }

        private void txtoid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtoid.Text = "";
            }
        }

        private void txtpid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtpid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtpid.Text = "";
            }
        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtquantity.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enteer non numeric vals");
                txtquantity.Text = "";
            }
        }
    }
}
